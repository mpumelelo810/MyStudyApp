from flask import render_template, flash, redirect, url_for, request, jsonify
from flask_login import login_required, current_user
from app import db
from app.content import bp
from app.content.models import Note, Question, Tag, NoteTag
from app.content.forms import NoteForm, QuestionForm

@bp.route('/notes/add', methods=['GET', 'POST'])
@login_required
def add_note():
    form = NoteForm()
    form.course.choices = [(c.id, c.code) for c in current_user.courses]
    form.section.choices = []
    
    if request.method == 'POST' and form.validate_on_submit():
        note = Note(
            section_id=form.section.data,
            title=form.title.data,
            content=form.content.data
        )
        db.session.add(note)
        
        # Handle tags
        tags = [t.strip() for t in form.tags.data.split(',') if t.strip()]
        for tag_name in tags:
            tag = Tag.query.filter_by(name=tag_name).first()
            if not tag:
                tag = Tag(name=tag_name)
                db.session.add(tag)
            note_tag = NoteTag(note=note, tag=tag)
            db.session.add(note_tag)
        
        db.session.commit()
        flash('Note added successfully!')
        return redirect(url_for('content.view_note', note_id=note.id))
    
    return render_template('content/add_note.html', title='Add Note', form=form)

@bp.route('/notes/<int:note_id>')
@login_required
def view_note(note_id):
    note = Note.query.get_or_404(note_id)
    return render_template('content/view_note.html', title=note.title, note=note)

@bp.route('/api/sections/<int:section_id>/notes')
@login_required
def get_section_notes(section_id):
    notes = Note.query.filter_by(section_id=section_id).all()
    return jsonify([{
        'id': note.id,
        'title': note.title,
        'content': note.content,
        'tags': [tag.name for tag in note.tags],
        'created_at': note.created_at.isoformat(),
        'updated_at': note.updated_at.isoformat()
    } for note in notes])

@bp.route('/questions/add', methods=['GET', 'POST'])
@login_required
def add_question():
    form = QuestionForm()
    form.course.choices = [(c.id, c.code) for c in current_user.courses]
    form.section.choices = []
    
    if form.validate_on_submit():
        question = Question(
            section_id=form.section.data,
            text=form.text.data,
            solution=form.solution.data,
            marks=form.marks.data,
            year=form.year.data,
            question_section=form.question_section.data
        )
        db.session.add(question)
        db.session.commit()
        flash('Question added successfully!')
        return redirect(url_for('content.view_question', question_id=question.id))
    
    return render_template('content/add_question.html', title='Add Question', form=form)