from datetime import datetime
from app import db

class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(16), index=True, unique=True)
    name = db.Column(db.String(128))
    title = db.Column(db.String(256))
    academic_year = db.Column(db.String(32))
    institution = db.Column(db.String(128))
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    sections = db.relationship('Section', backref='course', lazy='dynamic')
    users = db.relationship('UserCourse', backref='course', lazy='dynamic')

    def __repr__(self):
        return f'<Course {self.code}: {self.name}>'

class Section(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'))
    title = db.Column(db.String(128))
    description = db.Column(db.Text)
    icon = db.Column(db.String(64), default='fas fa-book')
    content_type = db.Column(db.String(32))  # 'notes' or 'questions'
    last_updated = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.relationship('Note', backref='section', lazy='dynamic')
    questions = db.relationship('Question', backref='section', lazy='dynamic')

    def __repr__(self):
        return f'<Section {self.title} of {self.course.code}>'