from flask import render_template, flash, redirect, url_for, request, jsonify
from flask_login import login_required, current_user
from app import db
from app.courses import bp
from app.courses.models import Course, Section
from app.courses.forms import CourseForm, SectionForm

@bp.route('/')
@login_required
def index():
    courses = current_user.courses.join(Course).all()
    return render_template('courses/index.html', title='My Courses', courses=courses)

@bp.route('/<course_code>')
@login_required
def view_course(course_code):
    course = Course.query.filter_by(code=course_code).first_or_404()
    sections = course.sections.order_by(Section.id).all()
    return render_template('courses/view.html', title=course.name, course=course, sections=sections)

@bp.route('/api/<course_code>/sections')
@login_required
def get_sections(course_code):
    course = Course.query.filter_by(code=course_code).first_or_404()
    sections = course.sections.order_by(Section.id).all()
    return jsonify([{
        'id': section.id,
        'title': section.title,
        'icon': section.icon,
        'content_type': section.content_type,
        'last_updated': section.last_updated.isoformat()
    } for section in sections])

@bp.route('/admin/add', methods=['GET', 'POST'])
@login_required
def add_course():
    if not current_user.is_admin:
        abort(403)
    form = CourseForm()
    if form.validate_on_submit():
        course = Course(
            code=form.code.data,
            name=form.name.data,
            title=form.title.data,
            academic_year=form.academic_year.data,
            institution=form.institution.data,
            description=form.description.data
        )
        db.session.add(course)
        db.session.commit()
        flash('Course added successfully!')
        return redirect(url_for('courses.index'))
    return render_template('courses/add.html', title='Add Course', form=form)