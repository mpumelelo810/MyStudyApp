document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Tab navigation
    const tabLinks = document.querySelectorAll('[data-bs-toggle="tab"]');
    tabLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const tab = new bootstrap.Tab(this);
            tab.show();
        });
    });

    // MathJax configuration
    if (typeof MathJax !== 'undefined') {
        MathJax = {
            tex: {
                inlineMath: [['$', '$'], ['\\(', '\\)']]
            },
            options: {
                enableMenu: false
            }
        };
    }

    // Service Worker for offline functionality
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', function() {
            navigator.serviceWorker.register('/service-worker.js').then(function(registration) {
                console.log('ServiceWorker registration successful with scope: ', registration.scope);
            }, function(err) {
                console.log('ServiceWorker registration failed: ', err);
            });
        });
    }

    // Dynamic content loading
    function loadSectionContent(sectionId) {
        fetch(`/api/sections/${sectionId}`)
            .then(response => response.json())
            .then(data => {
                const sectionElement = document.getElementById(sectionId);
                if (sectionElement) {
                    sectionElement.innerHTML = data.content;
                    if (typeof MathJax !== 'undefined') {
                        MathJax.typesetPromise();
                    }
                }
            })
            .catch(error => console.error('Error loading section:', error));
    }

    // Listen for tab changes to load content dynamically
    const tabPanes = document.querySelectorAll('.tab-pane');
    tabPanes.forEach(pane => {
        pane.addEventListener('shown.bs.tab', function() {
            loadSectionContent(this.id);
        });
    });
});