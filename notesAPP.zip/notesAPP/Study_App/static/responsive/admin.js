document.addEventListener('DOMContentLoaded', function() {
    // Toggle sidebar collapse
    document.getElementById('sidebarCollapse').addEventListener('click', function() {
        document.querySelector('.admin-container').classList.toggle('sidebar-collapsed');
    });
    
    // Preview note content with MathJax rendering
    document.getElementById('previewNote').addEventListener('click', function() {
        const previewContent = document.querySelector('.preview-content');
        const noteContent = document.getElementById('noteContent').value;
        
        // Process LaTeX delimiters
        let processedContent = noteContent.replace(/\$\$(.*?)\$\$/g, function(match, equation) {
            return `<div class="math-equation">$$${equation}$$</div>`;
        });
        
        previewContent.innerHTML = processedContent;
        document.getElementById('notePreview').style.display = 'block';
        
        // Trigger MathJax typesetting
        if (typeof MathJax !== 'undefined') {
            MathJax.typesetPromise();
        }
    });
    
    // Form submission handlers
    document.getElementById('notesForm').addEventListener('submit', function(e) {
        e.preventDefault();
        saveNote();
    });
    
    document.getElementById('questionsForm').addEventListener('submit', function(e) {
        e.preventDefault();
        saveQuestion();
    });
    
    // Save note to database (simulated)
    function saveNote() {
        const course = document.getElementById('courseSelect').value;
        const section = document.getElementById('sectionSelect').value;
        const title = document.getElementById('noteTitle').value;
        const content = document.getElementById('noteContent').value;
        const tags = document.getElementById('noteTags').value.split(',').map(tag => tag.trim());
        
        // In a real app, you would send this data to your backend
        console.log('Saving note:', {
            course,
            section,
            title,
            content,
            tags
        });
        
        alert('Note saved successfully!');
        this.reset();
        document.getElementById('notePreview').style.display = 'none';
    }
    
    // Save question to database (simulated)
    function saveQuestion() {
        const course = document.getElementById('questionCourse').value;
        const year = document.getElementById('questionYear').value;
        const section = document.getElementById('questionSection').value;
        const question = document.getElementById('questionText').value;
        const marks = document.getElementById('questionMarks').value;
        const solution = document.getElementById('solutionText').value;
        
        // In a real app, you would send this data to your backend
        console.log('Saving question:', {
            course,
            year,
            section,
            question,
            marks,
            solution
        });
        
        alert('Question saved successfully!');
        this.reset();
    }
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});

// Offline functionality
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        navigator.serviceWorker.register('/service-worker.js').then(function(registration) {
            console.log('ServiceWorker registration successful with scope: ', registration.scope);
        }, function(err) {
            console.log('ServiceWorker registration failed: ', err);
        });
    });
}

// Example service worker (service-worker.js would be a separate file)
// This would cache assets for offline use
const CACHE_NAME = 'study-app-v1';
const urlsToCache = [
    '/',
    '/static/css/admin.css',
    '/static/js/admin.js',
    'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css',
    'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js',
    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'
];

self.addEventListener('install', function(event) {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(function(cache) {
                return cache.addAll(urlsToCache);
            })
    );
});

self.addEventListener('fetch', function(event) {
    event.respondWith(
        caches.match(event.request)
            .then(function(response) {
                if (response) {
                    return response;
                }
                return fetch(event.request);
            })
    );
});